import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IncidenciaService } from 'src/app/menu-fm/service/incidencia.service';
import { CarteraEvento } from 'src/app/models/CarteraEvento';
import { EmailContacto } from 'src/app/models/EmailContacto';
import { FirmaEmail } from 'src/app/models/FirmaEmail';
import { AuthService } from 'src/app/users/service/auth.service';
import { VentasProspectosService } from '../ventas-prospectos/ventas-prospectos.component.service';
import Swal from 'sweetalert2';
import $ from 'jquery';
import { environment } from 'src/environments/environment.prod';
import { Router } from '@angular/router';
import { ContactoExpositor } from 'src/app/models/ContactoExpositor';
import { element } from 'protractor';

@Component({
  selector: 'app-email-masivos',
  templateUrl: './email-masivos.component.html',
  styleUrls: ['./email-masivos.component.css']
})
export class EmailMasivosComponent implements OnInit {
  
  public nuevoEmail: any;
  /** V A L I D A  E L  D I A */
  public validaDia: string;
  /**Ver Firmas con ID */
  urlPdfs: string = `${environment.endPointBack}/ventasProspectos/getImgFirma/`;
  public firmaEmail: FirmaEmail = new FirmaEmail();
  public nombreEditFirma: string = "";
  public nombreEditdescrip: string = "";
  public ArchivoEdit: string = "";
  /**Subir y editar Archivos Firmas */
  private imgUpdate: File;
  /** Subir Archivos */
  private fotoSeleccionada: File;
  private archivosE: File[] = [];
  public nombrePdf: string = "";
  public size: string = "";
  public tipoAr: string = "";
  public archivosFirma: Array<{ archivo: File, name: string, size: string, tipoAr: string }> = [];
  /**Pais y ciudad */
  public misPaises: any = [];
  public misEstados: any = [];
  public Car: any = [];
  // ID EVENTO SELECCIONADO
  public idEventoSelected: number = null;
  /**Ver Firmas */
  firmasEmail: FirmaEmail[];
  /** F o r m  Envio Email */
  formemailM: FormGroup;
  saveEmail: EmailContacto = new EmailContacto();
  /** F o r m  e n v i o  e m a i l  p r o g r a m a d o */
  formemailPro: FormGroup;
  /** F O R M Subir y Editar Firma */
  formFirmas: FormGroup;
  updaFirma: FormGroup;
  /**Nuevas Lineas */
  vaPais:FormGroup;

  
  
  /** C O M B O  H O R A  Y  M I N U T O*/
  public listaHrs: string[] = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"];
  public listaMnts: string[] = ["00", "15", "30", "45"];

  /**SUMMERNOTE Editar Firmas */

  correoEdit: any = {

    tabsize: 2,
    height: '100px',
    uploadImagePath: '/api/upload',
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['font', ['bold', 'italic']],
      ['para', ['style', 'ul', 'ol', 'paragraph']]
    ],
    fontNames: ['Helvetica', 'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Roboto', 'Times']
  };
  /** SUMMERNOTE REGISTRO FIRMA */
  Firma: any = {

    tabsize: 2,
    height: '200px',
    uploadImagePath: '/api/upload',
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph', 'height']],
      ['insert', ['table', 'link', 'hr']]
    ],
    fontNames: ['Helvetica', 'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Roboto', 'Times']
  };

  /**SUMMERNOTE Envio Email */
  correo5: any = {

    tabsize: 2,
    height: '200px',
    uploadImagePath: '/api/upload',
    toolbar: [
      ['misc', ['codeview', 'undo', 'redo']],
      ['style', ['bold', 'italic', 'underline', 'clear']],
      ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph', 'height']],
      ['insert', ['table', 'link', 'hr']]
    ],
    fontNames: ['Helvetica', 'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Roboto', 'Times']
  };
  constructor(private fb: FormBuilder,
    private menu: IncidenciaService,
    private ventasService: VentasProspectosService,
    private authService: AuthService,
    private router: Router,) { }

  ngOnInit(): void {
    this.menu.openEvent.subscribe(h => {
      this.idEventoSelected = h;
      //console.log(this.idEventoSelected);
      if (this.idEventoSelected != null && this.idEventoSelected != undefined && this.idEventoSelected != 0) {
        this.ValidEmail();
        this.verFirmas();
        this.seletCiudad();
        this.validarsubidaFirmas();
        this.validateUpdateFirma();
        this.validaFormEmailProgramado();
        this.mostrartime();
        this.validStatusP();
      }
      /**Nuevas Lineas */
      this.borrarPC();
    });   
  }


  /** Ver Firmas */
  public verFirmas() {
    this.ventasService.getFirmas().subscribe((result) => {
      if (result.length == 0) {
        return this.firmasEmail = null;
      }
      this.firmasEmail = result;
    }

    );

  }

  /**Ver Ciudad y Pais */
  public misestadoS: any = [];
  misPaisesC: string[] = [];
  misEstadosC: string[] = [];
  public dataEmail: Array<ContactoExpositor> = new Array<ContactoExpositor>();
  public dataContacto: Array<ContactoExpositor> = new Array<ContactoExpositor>();
/**Nuevas Lineas */
  borrarPC(){
    this.misEstados = [];
    this.misEstadosC = [];
    this.misPaises = [];
    this.misPaisesC = [];
    this.misEstadosCP = [];   
    
  }

  public validStatusP() {
    this.vaPais = this.fb.group({
      valPais:[''],
      valEstado:['']
     
    })
  }
 /** Fin de nuevas Lineas */

  seletCiudad() {

   this.borrarPC();
    this.dataEmail = [];
    this.checkTrue = [];

    this.ventasService.getMisExpositores(this.idEventoSelected).subscribe((res) => {
      if (res.length == 0) {
        return this.misPaises = null;
      }
      this.misPaises = res;
      this.misEstados = res;
      this.Car = res;

      /**Enviar Email */
      var array = res.map((e: any) => {
        e.expositor.contactoExpositor.map((item) => {
          this.dataEmail.push({ idContacto: item.id, expositor: item.expositor, puesto: item.puesto, nombre: item.nombre, telefono: item.telefono, email: item.email, img: item.img, checked: false, msjWhats: item.msjWhats });
        })
      });
      /** Ver Paises */
      this.misPaises.forEach(element => {
        let x = element.expositor.pais;
        let exist = this.misPaisesC.includes(x);
        if (!exist) {
          this.misPaisesC.push(x);
        }
      });


      this.checkTrue = this.dataEmail;
      this.dataContacto = this.dataEmail;



    })
  }


 
  /**Busqueda Paises */
  public dataEmai: Array<ContactoExpositor> = new Array<ContactoExpositor>();
  public showSearch = false;
  misEstadosCP: string[] = [];
  public paises(c) {
    this.showSearch = true;
    this.dataEmai = [];
    this.checkTrue = [];
    

    if (c == 0) {
      this.checkTrue = this.dataEmail;
    } else {
      let Paises = this.Car.filter(p => p.expositor.pais === c);
      const array = Paises.map((e: any) => {
        e.expositor.contactoExpositor.map((item) => {
          this.dataEmai.push({ idContacto: item.id, expositor: item.expositor, puesto: item.puesto, nombre: item.nombre, telefono: item.telefono, email: item.email, img: item.img, checked: false, msjWhats: item.msjWhats });
        })
      });
      this.checkTrue = this.dataEmai;
      /**Nuevas Lineas */
     let Paises2 = Paises.map(pc => pc.expositor.estado);
     this.misEstadosCP = Paises2;
     /** Fin Nuevas Lineas */

    }
  }

  /**Busqueda Estados */
  public estadoContacto: Array<ContactoExpositor> = new Array<ContactoExpositor>();
  public estados(c) {
    this.showSearch = false;
    this.estadoContacto = [];
    this.checkTrue = [];
    

    
    /**Nuevas Lineas */
    if(c == 0){
      this.checkTrue = this.dataEmail;
    }else{
      let estados = this.Car.filter(e => e.expositor.estado === c);
      let esta = estados.map((e: any) => {
        e.expositor.contactoExpositor.map((est) => {
          this.estadoContacto.push({ idContacto: est.id, expositor: est.expositor, puesto: est.puesto, nombre: est.nombre, telefono: est.telefono, email: est.email, img: est.img, checked: false, msjWhats: est.msjWhats });
  
        });
      });
      this.checkTrue = this.estadoContacto;

    }

   
  }

  /**Envio Email Normal */
  private ValidEmail() {
    this.formemailM = this.fb.group({
      firma: [],
      asunto: ['', Validators.required],
      descripcion: ['', Validators.required],
    })
  }

  public envioemailMasivo() {
    const fecha = new Date();
    let idFirmas = this.formemailM.controls.firma.value;
    if (idFirmas === null) {
      idFirmas = 1;
    }
    this.checkTrue.forEach((c) => {
      const idExpo = c.idContacto;
      if (c.checked) {
        this.saveEmail.firma = this.firmasEmail.find(f => f.id == idFirmas);
        this.saveEmail.asunto = this.formemailM.controls.asunto.value;
        this.saveEmail.descripcion = this.formemailM.controls.descripcion.value;
        this.saveEmail.fecha_programado = fecha;
        this.saveEmail.status = 0;

        /**Guarda mensaje a BD */
        this.ventasService.createCorreo(this.saveEmail, idExpo, this.authService.user.id)
          .subscribe((result) => {
            //console.log(result);
            let idcEx = result.Email.id;
            //console.log(idcEx);
            /**Guarda Archivos en BD*/
            this.archivosE.forEach(archivo => {
              this.ventasService.createarchivoContacto(archivo, idcEx)
                .subscribe((result) => {
                  //console.log(result);

                });

            });
            /**Manda Mensaje y Archivos a Email */
            this.ventasService.sendEmailProgramed(idcEx).subscribe((result) => {
              //console.log(result);
            }, error => {
              if (error.status == 500) {
                Swal.fire({
                  icon: 'info',
                  title: 'Error al enviar email.',
                  showConfirmButton: false,
                  timer: 1500
                })
                this.ventasService.deleteEmail(idcEx)
                  .subscribe((result) => {

                  })
              }
            })
            Swal.fire('Buen Trabajo!',
              'Email Enviado con Exito',
              'success')
            this.formemailM.reset();
            this.archivosE = [];
            this.archivosFirma = [];
            this.checkTrue = this.dataEmail;             
            this.desmarcar();

          })

      }
    })
  }
  desmarcar() {
    this.checkTrue.forEach(element => {
      const indexArrayEjemplo = this.checkTrue.findIndex(ejemplo => ejemplo.email === element.email);
      this.checkTrue[indexArrayEjemplo].checked = false;
    });
/**Nuevas Lineas */
    this.vaPais.reset();
    this.programScreen = false;
  }

  /** Valida check */
  valiarChe() {
    return !this.checkTrue.some(checkTrue => checkTrue.checked);
  }
  /**Subida de Archivos */
  saveArchivos(evt) {
    this.nombrePdf = "";
    this.size = "";

    var files = evt.target.files;
    var file = files[0];



    var extensiones_permitidas = new Array(".pptx", ".ppsx", ".pps", ".xlsx", ".odt", ".xls", ".docx", ".doc", ".txt", ".pdf", ".svg", ".ico", ".gif", ".jpeg", ".jpg", ".png");
    let extension = file.name.substring(file.name.lastIndexOf('.'), file.name.length);
    let permitida = false;

    for (var i = 0; i < extensiones_permitidas.length; i++) {
      if (extensiones_permitidas[i] == extension) {
        permitida = true;
        break;
      }
    } if (!permitida) {
      console.log(extension);

      Swal.fire({
        icon: 'error',
        text: 'Extensión no permitida.'
      })
    } else if (file.size > "104857600") {
      Swal.fire({
        icon: 'error',
        text: '1 Documento que intentaste añadir es mayor al límite de 100 MB.'
      })

    } else if (file.size <= "104857600") {
      if (files && file) {

        this.fotoSeleccionada = evt.target.files[0];
        this.archivosE.push(evt.target.files[0]);

        this.nombrePdf = file.name;
        this.size = file.size;
        this.tipoAr = extension;
        this.archivoFirma();
        return 1;
      }

    }
  }
  public archivoFirma() {
    $("#ArchivoEmail").val('');
    this.formatBytes(this.size);
    this.archivosFirma.push({
      archivo: this.fotoSeleccionada,
      name: this.nombrePdf,
      size: this.formatBytes(this.size),
      tipoAr: this.tipoAr
    });
  }
  deleteArchivo(i: number) {
    this.archivosFirma.splice(i, 1);
    this.archivosE.splice(i, 1);
    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'success',
      title: 'Archivo Eliminado !!',
      showConfirmButton: false,
      timer: 1500
    })

  }

  public formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  /** Subir Firmas */

  private validarsubidaFirmas() {
    this.formFirmas = this.fb.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required]
    });
  }

  /** Subir Y Editar foto */
  public updateFirm(evt) {
    this.imgUpdate = evt.target.files[0];
  }

  public saveFirm() {
    const nombre = this.formFirmas.controls.nombre.value;
    const descripcion = this.formFirmas.controls.descripcion.value;
    const archivo = this.imgUpdate;

    if (!archivo) {
      this.ventasService.createfirmaImg(descripcion, nombre).subscribe((res) => {
        if (res) {
          Swal.fire('Buen Trabajo!',
            'Firma Guardada con Exito',
            'success')
          this.formFirmas.reset();
          this.verFirmas();
        }
      }, error => {
        this.errorHTTP(error.status);
      });
    } else {
      this.ventasService.createFirmas(archivo, nombre, descripcion).subscribe((res) => {
        if (res) {
          Swal.fire('Buen Trabajo!',
            'Firma Guardada con Exito',
            'success')
          this.formFirmas.reset();
          this.verFirmas();
        }
      }, error => {
        this.errorHTTP(error.status);
      });

    }
    $("#Firmas").val('');
  }
  /**Nuevas Lineas */
  public programScreen = false;
  public buttonSave = false;
  /**Nuevas Lineas */
  public program(){    
    this.programScreen = true;
    this.buttonSave = true;
  }
  /**Update */
  public btnActulizar = false;
  

  public editshowFirm(c) {
    this.btnActulizar = false;
    this.ventasService.getFirma(c).subscribe((result) => {

      this.nombreEditFirma = result.nombre;
      this.nombreEditdescrip = result.descripcion;
      this.ArchivoEdit = result.archivo;

      this.updaFirma.patchValue({
        nombre:this.nombreEditFirma,
        descripcion:this.nombreEditdescrip
      })
    })
    
    
  }


  public validateUpdateFirma() {
    this.updaFirma = this.fb.group({
      firma: [],
      nombre: ['',Validators.required],
      descripcion: ['', Validators.required]
    })
  }
  public updateFirmas() {
    this.btnActulizar = true;
    const nombre = this.updaFirma.controls.nombre.value;
    const descripcion = this.updaFirma.controls.descripcion.value;
    const idFirma = this.updaFirma.controls.firma.value;
    const archivo = this.imgUpdate;

    //console.log(nombre, ' ', descripcion, ' ', idFirma);


    if (!this.imgUpdate) {
      this.ventasService.updSign(idFirma, nombre, descripcion).subscribe((res) => {
        if (res) {
          this.verFirmas();
          this.updaFirma.reset();
          this.btnActulizar = true;
          Swal.fire('¡Firma editada!', ``, 'success');
        }
      }, error => {
        this.errorHTTP(error.status);
      });
    } else {
      this.ventasService.updFirmas(idFirma, nombre, descripcion, archivo).subscribe((res) => {
        if (res) {
          this.verFirmas();
          this.updaFirma.reset();
          this.btnActulizar = true;
          Swal.fire('¡Firma editada!', ``, 'success');
        }
      }, error => {
        this.errorHTTP(error.status);
      });
    }
    $("#Firmas").val('');
  }


  /** Mensajes Programados */
  private validaFormEmailProgramado() {
    this.formemailPro = this.fb.group({
      fecha_programado: ['', Validators.required],
      hora_programado: ['Hora', Validators.required],
      minuto_programado: ['Minuto', Validators.required]
    })
  }

  public horaPro() {
    var fechaHo = new Date();
    let idFirma = this.formemailM.controls.firma.value;
    if (idFirma === null) {
      idFirma = 1;
    }

    var horaP = this.formemailPro.controls.hora_programado.value;
    var minutoP = this.formemailPro.controls.minuto_programado.value;
    var diaP = this.formemailPro.controls.fecha_programado.value;

    const año = diaP.slice(0, 4);
    const mes = diaP.slice(5, 7);
    const dia = diaP.substr(-2);

    const horaPr = new Date(año, mes - 1, dia, horaP, minutoP, 0);
    const horaA = new Date(año, mes - 1, dia, horaP, minutoP, 0);

    //this.saveEmail.contacto_expositor = this.nuevoCliente.id;
    this.saveEmail.firma = this.firmasEmail.find(f => f.id == idFirma);
    this.saveEmail.asunto = this.formemailM.controls.asunto.value;
    this.saveEmail.descripcion = this.formemailM.controls.descripcion.value;
    this.saveEmail.fecha_programado = horaPr;
    this.saveEmail.status = 1;

    var horas = fechaHo.getHours();
    var minutos = fechaHo.getMinutes();

    horaA.setHours(0, 0, 0, 0);
    fechaHo.setHours(0, 0, 0, 0);

    if (fechaHo.getTime() == horaA.getTime()) {
      if (horas >= horaP && minutos >= minutoP) {
        Swal.fire({
          toast: true,
          position: 'top-end',
          icon: 'info',
          title: 'No puedes mandar el correo a una hora menor ??',
          showConfirmButton: false,
          timer: 1500
        })

      } else {
        this.checkTrue.forEach((c) => {
          const idExpo = c.idContacto;
          if (c.checked) {
            this.ventasService.createCorreo(this.saveEmail, idExpo, this.authService.user.id)
              .subscribe((result) => {
                Swal.fire('Buen Trabajo!',
                  'Email Programado con Exito',
                  'success')
                //this.getshowEmail(this.nuevoCliente.id);
                this.formemailM.reset();
                this.formemailPro.reset();               
                this.desmarcar();
                this.validaFormEmailProgramado();
                this.checkTrue = this.dataEmail; 
                let idAx = result.Email.id;

                if (!this.fotoSeleccionada) {
                  this.formemailM.reset();
                  this.archivosE = [];
                  this.archivosFirma = [];
                  this.desmarcar();

                } else {
                  this.archivosE.forEach(archivo => {
                    this.ventasService.createarchivoContacto(archivo, idAx)
                      .subscribe((result) => {
                        this.formemailM.reset();
                        this.validaFormEmailProgramado();
                        this.archivosE = [];
                        this.archivosFirma = [];
                        this.checkTrue = this.dataEmail;
                        this.desmarcar();
                      })
                  })
                }
              });
          }
        })
      }
    } else {
      this.checkTrue.forEach((c) => {
        const idExpo = c.idContacto;
        if (c.checked) {
          this.ventasService.createCorreo(this.saveEmail, idExpo, this.authService.user.id)
            .subscribe((result) => {
              Swal.fire('Buen Trabajo!',
                'Email Programado con Exito',
                'success')
              this.formemailM.reset();
              this.formemailPro.reset();
              this.validaFormEmailProgramado();
              this.desmarcar();
              this.checkTrue = this.dataEmail; 
              let idAx = result.Email.id;
              if (!this.fotoSeleccionada) {
                this.formemailM.reset();
                this.archivosE = [];
                this.archivosFirma = [];
                this.checkTrue = this.dataEmail; 
                this.desmarcar();
              } else {
                this.archivosE.forEach(archivo => {
                  this.ventasService.createarchivoContacto(archivo, idAx)
                    .subscribe((result) => {
                      this.formemailM.reset();
                      this.validaFormEmailProgramado();
                      this.checkTrue = this.dataEmail; 
                      this.desmarcar();
                      this.archivosE = [];
                      this.archivosFirma = [];
                    })
                })
              }
            })
        }
      })
    }
  }
  /** Seleccionar Todos los Correos*/
  public checkTrue: Array<ContactoExpositor> = new Array<ContactoExpositor>();
  getEmailId(x: ContactoExpositor) {
    this.checkTrue.forEach(element => {
      if (element.email === x.email) {
        element.checked = !element.checked;
      }
    });
    this.envioemail();
  }
  seleccionartodoEmail(e) {
    let number = 0;
    if (e) {
      this.checkTrue.forEach(x => {
        x.checked = true;
        number = number + 1;



      });
      if (number > 151) {
        Swal.fire({
          title: '<strong>Error no puedes seleccionar: <u>' + number + '</u> contactos.</strong>',
          icon: 'info',
          html:
            'No se permite rebasar el numero de contactos ' +
            'superior a 150.'
        })

      }


    } else {
      this.checkTrue.forEach(x => {
        x.checked = false
      });
    }
  }
  eCheckedAll(): boolean {
    let verificar = 0;
    this.checkTrue.forEach(x => {
      if (x.checked) {
        verificar += 1;
      }
    });

    if (verificar === this.checkTrue.length) {

      return true;

    }
    return false;
  }
  public envioemail() {
    let n: number = 0;
    this.checkTrue.forEach(element => {
      if (element.checked) {
        n += 1;

      }
    });
    if (n > 0) {
      return true;
    }
    return false;
  }
  public vSearch: string = '';
  searchContact(x: string) {
    this.limpiar();

    this.showSearch = false;
    this.vSearch = x;
    this.checkTrue = this.dataContacto;
    if (x !== '') {
      this.checkTrue = this.checkTrue.filter(c => c.nombre.toLowerCase().includes(x.toLowerCase()));
      if (this.checkTrue.length === 0) {
        //this.emptySearch = true;
      }
    }
  }



  mostrartime() {
    var f = new Date();
    this.validaDia = new Date(f.getTime() - (f.getTimezoneOffset() * 60000))
      .toISOString()
      .split("T")[0];
  }

  limpiar() {
    this.estadoContacto = [];
    this.dataEmai = [];
    this.vaPais.reset();
    
  }

  //ErrorHTTP
  private errorHTTP(status: number) {
    if (status == 401) {
      this.authService.logout();
      this.router.navigate(['/']);
    } else if (status == 500) {
      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success btn-sm'
        },
        buttonsStyling: false
      })
      Swal.fire({
        customClass: {
          confirmButton: 'btn btn-info btn-sm'
        },
        title: "Server Error.",
        buttonsStyling: false,
        html: "<img src='./assets/img_project/excepciones/error500.jpg' class='img-fluid' alt='Server Error'>",
        confirmButtonText: 'Entiendo'
      })
    } else if (status == 0) {
      const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success btn-sm'
        },
        buttonsStyling: false
      })
      Swal.fire({
        customClass: {
          confirmButton: 'btn btn-info btn-sm'
        },
        title: "",
        buttonsStyling: false,
        html: "<img src='./assets/img_project/excepciones/errorConexion.jpg' class='img-fluid' alt='Error de conexion'>",
        confirmButtonText: 'Entiendo'
      })
    }
  }


}
